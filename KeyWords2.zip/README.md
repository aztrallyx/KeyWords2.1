# KeyWords

App Android local para practicar contraseñas. Sin permisos (sin internet), teclado propio, bóveda cifrada.

1. Crea un repo PRIVADO en GitHub y sube todos los archivos de esta carpeta (incluida `.github/workflows/build.yml`).
2. Pestaña Actions > "Build KeyWords APK" (corre solo al subir, o con "Run workflow").
3. Al terminar, descarga el artefacto KeyWords-apk (abajo de la ejecución) y instala el .apk.

Exporta un respaldo cifrado (Ajustes) antes de actualizar la app. Sin la contraseña maestra no hay recuperación.
