package com.keywords.app

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.security.SecureRandom
import kotlin.math.ln

/** Text buffer with a cursor. Our own keyboard writes into it; the system keyboard is never used. */
class TextBuf(initial: String = "") {
    private var raw by mutableStateOf(initial)
    var cursor by mutableIntStateOf(initial.length)

    /** Setting the text from outside (clear, prefill) puts the cursor at the end. */
    var text: String
        get() = raw
        set(v) {
            raw = v
            cursor = v.length
        }

    fun insert(s: String) {
        val c = cursor.coerceIn(0, raw.length)
        raw = raw.substring(0, c) + s + raw.substring(c)
        cursor = c + s.length
    }

    fun backspace() {
        val c = cursor.coerceIn(0, raw.length)
        if (c > 0) {
            raw = raw.removeRange(c - 1, c)
            cursor = c - 1
        }
    }

    fun moveLeft() {
        cursor = (cursor.coerceIn(0, raw.length) - 1).coerceAtLeast(0)
    }

    fun moveRight() {
        cursor = (cursor.coerceIn(0, raw.length) + 1).coerceAtMost(raw.length)
    }
}

class KbController {
    var target by mutableStateOf<TextBuf?>(null)
}

private enum class Layer { LETTERS, SYM1, SYM2 }
private enum class Shift { OFF, ONCE, LOCK }

private val BG = Color(0xFF1B1C1F)
private val KEY = Color(0xFF3A3C41)
private val FN = Color(0xFF2B2D31)
private val PRESSED = Color(0xFF5A5D63)
private val ACCENT = Color(0xFF80CBC4)
private val ACCENT_DIM = Color(0xFF3E6F69)

private const val SYM1_R1 = "@#\$_&-+()/"
private const val SYM1_R2 = "%=*\"':;!?^"
private const val SYM1_R3 = "~`\\|<>"
private const val SYM2_R1 = "[]{}£¢€¥°•"
private const val SYM2_R2 = "√π÷×¶∆©®™±"
private const val SYM2_R3 = "✓§№«»…"

/** Long-press alternates (accents and extra symbols), like Gboard. */
private val ALTS = mapOf(
    "a" to "áàäâãå", "e" to "éèëê", "i" to "íìïî", "o" to "óòöôõ", "u" to "úùüû",
    "n" to "ñ", "c" to "ç", "y" to "ýÿ", "s" to "ß",
    "." to "!?:;-_@/", "," to ";:", "?" to "¿", "!" to "¡", "\$" to "€£¥¢",
    "-" to "–—_•", "'" to "‘’`", "\"" to "“”«»", "/" to "\\|", "=" to "≠≈",
    "+" to "±", "%" to "‰", "*" to "†‡", "#" to "№", "&" to "§", "(" to "[{<", ")" to "]}>"
)

private fun altsFor(c: String): List<String>? {
    val low = c.lowercase()
    val base = ALTS[low] ?: return null
    val up = c != low
    return base.map { if (up) it.toString().uppercase() else it.toString() }
}

@Composable
fun SecureKeyboard(target: TextBuf, shuffle: Boolean, onDone: () -> Unit) {
    var layer by remember { mutableStateOf(Layer.LETTERS) }
    var shift by remember { mutableStateOf(Shift.OFF) }
    var lastShiftTap by remember { mutableLongStateOf(0L) }
    var alts by remember { mutableStateOf<List<String>>(emptyList()) }
    val letters = remember(target, shuffle) {
        val base = "qwertyuiopasdfghjklñzxcvbnm".map { it.toString() }
        if (shuffle) base.shuffled(SecureRandom()) else base
    }

    val onType: (String) -> Unit = { s ->
        alts = emptyList()
        target.insert(s)
        if (shift == Shift.ONCE) shift = Shift.OFF
    }
    val onAlts: (List<String>) -> Unit = { list -> alts = list }
    val back: () -> Unit = {
        alts = emptyList()
        target.backspace()
    }
    val shown: (String) -> String = { s -> if (shift == Shift.OFF) s else s.uppercase() }

    Column(Modifier.fillMaxWidth().background(BG).padding(horizontal = 3.dp, vertical = 2.dp)) {
        // Top strip: cursor arrows, or the long-press alternates.
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (alts.isNotEmpty()) {
                alts.forEach { a ->
                    KbKey(a, Modifier.weight(1f), bg = KEY, height = 36.dp) { onType(a) }
                }
                KbKey("✕", Modifier.weight(1f), bg = FN, height = 36.dp, fontSize = 16.sp) { alts = emptyList() }
            } else {
                KbKey("◀", Modifier.weight(1f), bg = FN, height = 36.dp, fontSize = 16.sp, repeat = true) {
                    target.moveLeft()
                }
                KbKey("▶", Modifier.weight(1f), bg = FN, height = 36.dp, fontSize = 16.sp, repeat = true) {
                    target.moveRight()
                }
                Spacer(Modifier.weight(7f))
                KbKey("⌄", Modifier.weight(1f), bg = FN, height = 36.dp, fontSize = 18.sp) { onDone() }
            }
        }

        // Number row
        Row(Modifier.fillMaxWidth()) {
            "1234567890".forEach { ch ->
                CharKey(ch.toString(), onType, onAlts, height = 38.dp, size = 18.sp)
            }
        }

        when (layer) {
            Layer.LETTERS -> {
                Row(Modifier.fillMaxWidth()) {
                    letters.subList(0, 10).forEach { l -> CharKey(shown(l), onType, onAlts) }
                }
                Row(Modifier.fillMaxWidth()) {
                    letters.subList(10, 20).forEach { l -> CharKey(shown(l), onType, onAlts) }
                }
                Row(Modifier.fillMaxWidth()) {
                    KbKey(
                        if (shift == Shift.LOCK) "⇪" else "⇧",
                        Modifier.weight(1.45f),
                        bg = if (shift == Shift.OFF) FN else ACCENT_DIM
                    ) {
                        alts = emptyList()
                        val now = System.currentTimeMillis()
                        shift = when {
                            shift == Shift.LOCK -> Shift.OFF
                            shift == Shift.ONCE && now - lastShiftTap < 350 -> Shift.LOCK
                            shift == Shift.ONCE -> Shift.OFF
                            else -> Shift.ONCE
                        }
                        lastShiftTap = now
                    }
                    letters.subList(20, 27).forEach { l -> CharKey(shown(l), onType, onAlts) }
                    KbKey("⌫", Modifier.weight(1.45f), bg = FN, repeat = true) { back() }
                }
            }
            Layer.SYM1 -> {
                Row(Modifier.fillMaxWidth()) { SYM1_R1.forEach { CharKey(it.toString(), onType, onAlts) } }
                Row(Modifier.fillMaxWidth()) { SYM1_R2.forEach { CharKey(it.toString(), onType, onAlts) } }
                Row(Modifier.fillMaxWidth()) {
                    KbKey("=\\<", Modifier.weight(1.7f), bg = FN, fontSize = 16.sp) {
                        alts = emptyList(); layer = Layer.SYM2
                    }
                    SYM1_R3.forEach { CharKey(it.toString(), onType, onAlts) }
                    KbKey("⌫", Modifier.weight(1.7f), bg = FN, repeat = true) { back() }
                }
            }
            Layer.SYM2 -> {
                Row(Modifier.fillMaxWidth()) { SYM2_R1.forEach { CharKey(it.toString(), onType, onAlts) } }
                Row(Modifier.fillMaxWidth()) { SYM2_R2.forEach { CharKey(it.toString(), onType, onAlts) } }
                Row(Modifier.fillMaxWidth()) {
                    KbKey("?123", Modifier.weight(1.7f), bg = FN, fontSize = 16.sp) {
                        alts = emptyList(); layer = Layer.SYM1
                    }
                    SYM2_R3.forEach { CharKey(it.toString(), onType, onAlts) }
                    KbKey("⌫", Modifier.weight(1.7f), bg = FN, repeat = true) { back() }
                }
            }
        }

        // Bottom row
        Row(Modifier.fillMaxWidth()) {
            KbKey(
                if (layer == Layer.LETTERS) "?123" else "ABC",
                Modifier.weight(1.5f), bg = FN, fontSize = 16.sp
            ) {
                alts = emptyList()
                layer = if (layer == Layer.LETTERS) Layer.SYM1 else Layer.LETTERS
            }
            CharKey(",", onType, onAlts)
            KbKey("espacio", Modifier.weight(4.2f), fontSize = 14.sp) { onType(" ") }
            CharKey(".", onType, onAlts)
            KbKey("Listo", Modifier.weight(1.6f), bg = ACCENT, fg = Color(0xFF00201D), fontSize = 15.sp) {
                alts = emptyList()
                onDone()
            }
        }
    }
}

@Composable
private fun RowScope.CharKey(
    c: String,
    onType: (String) -> Unit,
    onAlts: (List<String>) -> Unit,
    height: Dp = 46.dp,
    size: TextUnit = 21.sp
) {
    val list = altsFor(c)
    val longCb: (() -> Unit)? = list?.let { l -> { onAlts(l) } }
    KbKey(
        c, Modifier.weight(1f),
        fontSize = size, height = height,
        preview = if (App.keyPreview) c else null,
        onLongPress = longCb
    ) { onType(c) }
}

@Composable
private fun KbKey(
    label: String,
    modifier: Modifier,
    bg: Color = KEY,
    fg: Color = Color.White,
    fontSize: TextUnit = 21.sp,
    height: Dp = 46.dp,
    repeat: Boolean = false,
    preview: String? = null,
    onLongPress: (() -> Unit)? = null,
    onTap: () -> Unit
) {
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    var pressed by remember { mutableStateOf(false) }
    val repeated = remember { booleanArrayOf(false) }
    // The gesture block below is not restarted on recomposition, so always read the latest lambdas:
    val tap by rememberUpdatedState(onTap)
    val long by rememberUpdatedState(onLongPress)
    val hasLong = onLongPress != null

    Box(modifier.padding(horizontal = 2.5.dp, vertical = 3.dp).height(height)) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(8.dp))
                .background(if (pressed) PRESSED else bg)
                .pointerInput(repeat, hasLong) {
                    val longCb: (Offset) -> Unit = { long?.invoke() }
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            repeated[0] = false
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            if (repeat) {
                                val job = scope.launch {
                                    delay(380)
                                    repeated[0] = true
                                    while (true) {
                                        tap()
                                        delay(45)
                                    }
                                }
                                tryAwaitRelease()
                                job.cancel()
                            } else {
                                tryAwaitRelease()
                            }
                            pressed = false
                        },
                        onLongPress = if (hasLong) longCb else null,
                        onTap = { if (!repeated[0]) tap() }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Text(label, color = fg, fontSize = fontSize)
        }
        if (pressed && preview != null) KeyBubble(preview)
    }
}

/** Gboard-style magnified key preview (optional, off by default: it shows what you touch). */
@Composable
private fun KeyBubble(text: String) {
    val up = with(LocalDensity.current) { (-64).dp.roundToPx() }
    Popup(alignment = Alignment.TopCenter, offset = IntOffset(0, up)) {
        Box(
            Modifier.size(52.dp, 60.dp).clip(RoundedCornerShape(10.dp)).background(PRESSED),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = Color.White, fontSize = 28.sp)
        }
    }
}

/** Display-only field. Tap it to focus (opens our keyboard) and tap a character to place the cursor there. */
@Composable
fun SField(label: String, buf: TextBuf, secret: Boolean = false, reveal: Boolean = false) {
    val active = App.kb.target === buf
    val shape = RoundedCornerShape(8.dp)
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val cursorColor = MaterialTheme.colorScheme.primary
    val padPx = with(LocalDensity.current) { 12.dp.toPx() }
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .clip(shape)
                .border(
                    if (active) 2.dp else 1.dp,
                    if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                    shape
                )
                .pointerInput(buf) {
                    detectTapGestures(
                        onTap = { pos ->
                            App.kb.target = buf
                            val l = layout
                            if (l != null) {
                                val i = l.getOffsetForPosition(Offset(pos.x - padPx, pos.y - padPx))
                                buf.cursor = i.coerceIn(0, buf.text.length)
                            } else {
                                buf.cursor = buf.text.length
                            }
                        }
                    )
                }
                .padding(12.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            val shownText = if (secret && !reveal) "•".repeat(buf.text.length) else buf.text
            Text(
                shownText,
                fontFamily = FontFamily.Monospace,
                fontSize = 16.sp,
                onTextLayout = { layout = it },
                modifier = Modifier.drawBehind {
                    val l = layout
                    if (active && l != null) {
                        val len = l.layoutInput.text.length
                        val r = l.getCursorRect(buf.cursor.coerceIn(0, len))
                        drawLine(cursorColor, r.topCenter, r.bottomCenter, strokeWidth = 2.dp.toPx())
                    }
                }
            )
        }
    }
}

fun strengthBits(p: String): Double {
    if (p.isEmpty()) return 0.0
    var pool = 0
    if (p.any { it.isLowerCase() }) pool += 26
    if (p.any { it.isUpperCase() }) pool += 26
    if (p.any { it.isDigit() }) pool += 10
    if (p.any { !it.isLetterOrDigit() }) pool += 32
    if (pool == 0) pool = 26
    val effLen = minOf(p.length, p.toSet().size * 2)
    var bits = effLen * ln(pool.toDouble()) / ln(2.0)
    val low = p.lowercase()
    if (listOf("password", "123456", "qwerty", "abc", "admin", "letmein", "contrase").any { low.contains(it) }) bits *= 0.5
    return bits
}

@Composable
fun StrengthMeter(p: String) {
    if (p.isEmpty()) return
    val bits = strengthBits(p)
    val (label, color) = when {
        bits < 28 -> "Muy débil" to Color(0xFFE53935)
        bits < 40 -> "Débil" to Color(0xFFFB8C00)
        bits < 60 -> "Regular" to Color(0xFFFDD835)
        bits < 80 -> "Fuerte" to Color(0xFF7CB342)
        else -> "Muy fuerte" to Color(0xFF43A047)
    }
    Column(Modifier.padding(vertical = 4.dp)) {
        LinearProgressIndicator(
            progress = { (bits / 100.0).coerceIn(0.05, 1.0).toFloat() },
            color = color,
            modifier = Modifier.fillMaxWidth()
        )
        Text("Seguridad: $label (~${bits.toInt()} bits)", fontSize = 12.sp)
    }
}
