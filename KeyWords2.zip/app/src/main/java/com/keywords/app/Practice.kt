package com.keywords.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class PMode(val label: String) { TYPE("Escribirla"), CARDS("Tarjetas"), MIXED("Mixto") }
enum class Feedback(val label: String) { NONE("Solo incorrecto"), COUNT("Cuántos coinciden"), POSITIONS("Marcar posiciones") }
enum class QState { ASKING, RIGHT, GAVE_UP }

data class SessionConfig(
    val ids: List<String>,
    val mode: PMode,
    val hintFirst: Boolean,
    val hintLen: Boolean,
    val feedback: Feedback,
    val attempts: Int, // 0 = unlimited
    val exam: Boolean
)

/** Practice setup that survives switching tabs. Cleared on lock. */
object PP {
    val selected = mutableStateListOf<String>()
    var inited by mutableStateOf(false)
    var mode by mutableStateOf(PMode.MIXED)
    var hintFirst by mutableStateOf(true)
    var hintLen by mutableStateOf(true)
    var feedback by mutableStateOf(Feedback.POSITIONS)
    var attempts by mutableIntStateOf(3)

    fun reset() {
        selected.clear()
        inited = false
    }
}

// ------------------------------------------------------------ Setup tab

@Composable
fun PracticeTab() {
    LaunchedEffect(Unit) {
        if (!PP.inited) {
            PP.selected.addAll(App.accounts.map { it.id })
            PP.inited = true
        }
    }
    val groups = App.accounts
        .groupBy { it.category.ifBlank { "Sin categoría" } }
        .toSortedMap(String.CASE_INSENSITIVE_ORDER)
    val ids = PP.selected.filter { id -> App.accounts.any { it.id == id } }

    LazyColumn(contentPadding = PaddingValues(16.dp)) {
        item { Text("Práctica", style = MaterialTheme.typography.headlineMedium) }

        item {
            Label("Modo")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PMode.values().forEach { m ->
                    FilterChip(selected = PP.mode == m, onClick = { PP.mode = m }, label = { Text(m.label) })
                }
            }
            Label("Pistas que me permito")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = PP.hintFirst, onCheckedChange = { PP.hintFirst = it })
                Spacer(Modifier.width(8.dp)); Text("Primera letra")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = PP.hintLen, onCheckedChange = { PP.hintLen = it })
                Spacer(Modifier.width(8.dp)); Text("Longitud")
            }
            Label("Cuando me equivoco")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Feedback.values().forEach { f ->
                    FilterChip(selected = PP.feedback == f, onClick = { PP.feedback = f }, label = { Text(f.label) })
                }
            }
            Label("Intentos antes de mostrar la respuesta")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 2, 3, 0).forEach { n ->
                    FilterChip(
                        selected = PP.attempts == n,
                        onClick = { PP.attempts = n },
                        label = { Text(if (n == 0) "Nunca" else "$n") }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    App.screen = Screen.Session(
                        SessionConfig(ids, PP.mode, PP.hintFirst, PP.hintLen, PP.feedback, PP.attempts, false)
                    )
                },
                enabled = ids.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Empezar práctica (${ids.size})") }
            OutlinedButton(
                onClick = {
                    App.screen = Screen.Session(
                        SessionConfig(ids, PMode.TYPE, false, false, Feedback.NONE, 1, true)
                    )
                },
                enabled = ids.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Empezar examen (sin pistas, un intento)") }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 16.dp)) {
                Text("Cuentas a practicar", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    PP.selected.clear(); PP.selected.addAll(App.accounts.map { it.id })
                }) { Text("Todas") }
                TextButton(onClick = { PP.selected.clear() }) { Text("Ninguna") }
            }
            if (App.accounts.isEmpty()) Text("Primero agrega cuentas (pestaña Cuentas).")
        }

        groups.forEach { (cat, list) ->
            item(key = "ph$cat") {
                val all = list.all { it.id in PP.selected }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = all, onCheckedChange = { c ->
                        if (c) {
                            list.forEach { if (it.id !in PP.selected) PP.selected.add(it.id) }
                        } else {
                            PP.selected.removeAll(list.map { it.id }.toSet())
                        }
                    })
                    Text(cat, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
            items(list.sortedBy { it.name.lowercase() }, key = { "pa" + it.id }) { a ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 16.dp)) {
                    Checkbox(checked = a.id in PP.selected, onCheckedChange = { c ->
                        if (c) PP.selected.add(a.id) else PP.selected.remove(a.id)
                    })
                    Column {
                        Text(a.name)
                        if (a.username.isNotBlank()) Text(a.username, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun Label(t: String) {
    Text(t, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
}

// ------------------------------------------------------------ Session

@Composable
fun SessionScreen(cfg: SessionConfig) {
    BackHandler { App.kb.target = null; App.screen = Screen.Home }
    val queue = remember { mutableStateListOf<String>().apply { addAll(cfg.ids.shuffled()) } }
    val requeued = remember { mutableSetOf<String>() }
    val results = remember { mutableStateListOf<Pair<String, Boolean>>() }
    var index by remember { mutableIntStateOf(0) }

    if (index >= queue.size) {
        ResultView(cfg, results)
    } else {
        val acc = App.accounts.firstOrNull { it.id == queue[index] }
        if (acc != null) {
            key(index) {
                Question(cfg, acc, "Pregunta ${index + 1} de ${queue.size}") { ok ->
                    App.record(acc.id, ok)
                    results.add(acc.name to ok)
                    if (!ok && !cfg.exam && requeued.add(acc.id)) queue.add(acc.id)
                    index++
                }
            }
        }
    }
}

@Composable
fun Question(cfg: SessionConfig, acc: Account, progress: String, onDone: (Boolean) -> Unit) {
    val scope = rememberCoroutineScope()
    val coin = remember { Random.nextBoolean() }
    val card = !cfg.exam && !acc.strict && (cfg.mode == PMode.CARDS || (cfg.mode == PMode.MIXED && coin))
    val buf = remember { TextBuf() }
    var show by remember { mutableStateOf(false) }
    var tries by remember { mutableIntStateOf(0) }
    var state by remember { mutableStateOf(QState.ASKING) }
    var feedback by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var revealed by remember { mutableStateOf(false) }
    var showFirst by remember { mutableStateOf(false) }
    var showLen by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { App.kb.target = if (card) null else buf }

    fun check() {
        scope.launch {
            busy = true
            val good = App.matches(acc, buf.text)
            busy = false
            if (cfg.exam) {
                onDone(good)
            } else if (good) {
                feedback = ""
                state = QState.RIGHT
                App.kb.target = null
            } else {
                tries++
                feedback = makeFeedback(acc, buf.text, cfg.feedback)
                if (cfg.attempts > 0 && tries >= cfg.attempts) {
                    state = QState.GAVE_UP
                    App.kb.target = null
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text(progress, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Text(acc.name, style = MaterialTheme.typography.headlineMedium)
        if (acc.username.isNotBlank()) {
            Text(acc.username, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(12.dp))

        if (!cfg.exam && (cfg.hintFirst || cfg.hintLen) && state == QState.ASKING) {
            if (acc.strict) {
                Text("Cuenta estricta: sin pistas.", fontSize = 12.sp)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (cfg.hintFirst) OutlinedButton(onClick = { showFirst = true }) { Text("Primera letra") }
                    if (cfg.hintLen) OutlinedButton(onClick = { showLen = true }) { Text("Longitud") }
                }
                if (showFirst) Text("Primer carácter: ${acc.password.firstOrNull() ?: ""}")
                if (showLen) Text("Longitud: ${acc.password.length} caracteres")
            }
            Spacer(Modifier.height(8.dp))
        }

        if (card) {
            if (!revealed) {
                Button(onClick = { revealed = true }, modifier = Modifier.fillMaxWidth()) { Text("Mostrar respuesta") }
            } else {
                Text(acc.password, fontFamily = FontFamily.Monospace, fontSize = 22.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onDone(true) }) { Text("✓ Me la sabía") }
                    OutlinedButton(onClick = { onDone(false) }) { Text("✗ Fallé") }
                }
            }
        } else {
            SField("Escribe la contraseña", buf, secret = true, reveal = show)
            Row {
                TextButton(onClick = { show = !show }) { Text(if (show) "Ocultar" else "Mostrar") }
                TextButton(onClick = { buf.text = "" }) { Text("Borrar") }
            }
            if (feedback.isNotEmpty()) {
                Text(feedback, color = MaterialTheme.colorScheme.error, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(8.dp))
            }
            when (state) {
                QState.ASKING -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { check() }, enabled = buf.text.isNotEmpty() && !busy) {
                        Text(if (busy) "Revisando…" else "Revisar")
                    }
                    OutlinedButton(onClick = {
                        if (cfg.exam) {
                            onDone(false)
                        } else {
                            App.kb.target = null
                            state = QState.GAVE_UP
                        }
                    }) { Text(if (cfg.exam) "Saltar" else "Me rindo") }
                }
                QState.RIGHT -> Column {
                    Text("✓ ¡Correcto!", color = Color(0xFF66BB6A), fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onDone(tries == 0) }) { Text("Siguiente") }
                }
                QState.GAVE_UP -> Column {
                    if (acc.strict) {
                        Text("Respuesta no disponible (cuenta estricta).")
                    } else {
                        Text("Respuesta: ${acc.password}", fontFamily = FontFamily.Monospace, fontSize = 18.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onDone(false) }) { Text("Siguiente") }
                }
            }
        }
    }
}

private fun makeFeedback(acc: Account, typed: String, fb: Feedback): String {
    if (acc.strict || fb == Feedback.NONE) return "Incorrecto."
    val real = acc.password
    return when (fb) {
        Feedback.COUNT -> {
            val m = typed.indices.count { it < real.length && typed[it] == real[it] }
            "Incorrecto. $m de ${real.length} caracteres coinciden en su posición."
        }
        Feedback.POSITIONS -> {
            val sb = StringBuilder()
            val n = maxOf(typed.length, real.length)
            for (i in 0 until n) {
                sb.append(if (i < typed.length && i < real.length && typed[i] == real[i]) "✓" else "✗")
            }
            "Incorrecto.\n$sb" + if (typed.length != real.length) "\n(La longitud no coincide: escribiste ${typed.length}, eran ${real.length})" else ""
        }
        else -> "Incorrecto."
    }
}

@Composable
fun ResultView(cfg: SessionConfig, results: List<Pair<String, Boolean>>) {
    val ok = results.count { it.second }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text(if (cfg.exam) "Examen terminado" else "Práctica terminada", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("$ok de ${results.size} correctas al primer intento", fontSize = 18.sp)
        Spacer(Modifier.height(12.dp))
        results.forEach { (n, good) -> Text((if (good) "✓ " else "✗ ") + n) }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            App.kb.target = null
            App.tab = Tab.PRACTICE
            App.screen = Screen.Home
        }) { Text("Volver") }
    }
}
